import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';
import { AlphaListPage } from '../alpha-list/alpha-list';

import { TrumbowygModule} from 'ng2-lazy-trumbowyg';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  alphaListPage: Component;

  public initialContentOne: string = `<h2>This is an initial title One.</h2><p>This is an initial content.</p><p><img src="https://angular.io/assets/images/home/loved-by-millions.png" alt=""><br></p><p><br></p>`
  public initialContentTwo: string = `<h2>This is an initial title Two.</h2><p>This is an initial content.</p><p><img src="https://github.com/Alex-D/Trumbowyg/raw/develop/banner.png" alt=""><br></p><p><br></p>`
  public contentOne: string;
  public contentTwo: string;

  public options1: any = {
    autogrow: true,
    removeformatPasted: true,
    semantic: false,
    btns: [['bold', 'italic'], ['link']],
    lang: 'fr'
  };

  public options2: any = {
    lang: 'ru'
  };


  constructor(public navCtrl: NavController) {
    this.alphaListPage = AlphaListPage;

    console.log('edit'+TrumbowygModule);

  }

}
